import { ChangeDetectionStrategy, Component } from '@angular/core';
import { StatsCardsComponent } from './stats-cards/stats-cards.component';
import { TapsComponent } from './taps/taps.component';
import { DashboardContentComponent } from './dashboard-content/dashboard-content.component';

@Component({
  selector: 'main-content',
  imports: [StatsCardsComponent, TapsComponent, DashboardContentComponent],
  templateUrl: './Main-content.component.html',
  styleUrls: ['./Main-content.component.css'],
})
export class MainContentComponent { }
