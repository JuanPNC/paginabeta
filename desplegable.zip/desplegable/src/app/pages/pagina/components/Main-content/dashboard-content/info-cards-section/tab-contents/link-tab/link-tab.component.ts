import {  Component } from '@angular/core';

@Component({
  selector: 'link-tab',
  imports: [],
  templateUrl: './link-tab.component.html',
  styleUrls: ['./../tab-contents.component.css'],
})
export class LinkTabComponent { }
