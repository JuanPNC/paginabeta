import { Component } from '@angular/core';

@Component({
  selector: 'calc-tab',
  imports: [],
  templateUrl: './calc-tab.component.html',
  styleUrls: ['./../tab-contents.component.css'],
  
})
export class CalcTabComponent { }
