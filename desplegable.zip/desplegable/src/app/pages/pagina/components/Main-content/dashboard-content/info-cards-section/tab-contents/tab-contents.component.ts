import { Component } from '@angular/core';


@Component({
  selector: 'tab-contents',
  imports: [],
  templateUrl: './tab-contents.component.html',
  styleUrls: ['./tab-contents.component.css'],
})
export class TabContentsComponent { }
