import { ChangeDetectionStrategy, Component } from '@angular/core';
import { TabContentsComponent } from './tab-contents/tab-contents.component';

@Component({
  selector: 'info-cards-section',
  imports: [TabContentsComponent],
  templateUrl: './info-cards-section.component.html',
})
export class InfoCardsSectionComponent { }
