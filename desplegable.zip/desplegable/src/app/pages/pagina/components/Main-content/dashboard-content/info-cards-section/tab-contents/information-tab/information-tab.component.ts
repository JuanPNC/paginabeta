import { Component } from '@angular/core';

@Component({
  selector: 'information-tab',
  imports: [],
  templateUrl: './information-tab.component.html',
  styleUrls: ['./../tab-contents.component.css'],
})
export class InformationTabComponent { }
