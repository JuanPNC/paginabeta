import { ChangeDetectionStrategy, Component } from '@angular/core';
import { InfoCardsSectionComponent } from './info-cards-section/info-cards-section.component';

@Component({
  selector: 'dashboard-content',
  imports: [InfoCardsSectionComponent],
  templateUrl: './dashboard-content.component.html',
  styleUrls: ['./dashboard-content.component.css'],
})
export class DashboardContentComponent { }
