import {  Component } from '@angular/core';

@Component({
  selector: 'buttons-tab',
  imports: [],
  templateUrl: './buttons-tab.component.html',
  styleUrls: ['./../tab-contents.component.css'],
})
export class ButtonsTabComponent { }
