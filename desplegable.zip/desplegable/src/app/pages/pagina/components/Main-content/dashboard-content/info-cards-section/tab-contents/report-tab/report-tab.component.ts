import { Component } from '@angular/core';

@Component({
  selector: 'report-tab',
  imports: [],
  templateUrl: './report-tab.component.html',
  styleUrls: ['./../tab-contents.component.css'],
})
export class ReportTabComponent { }
