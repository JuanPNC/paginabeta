import {  Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';



@Component({
  selector: 'taps',
  imports: [RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './taps.component.html',
  styleUrls: ['./taps.component.css'],
})
export class TapsComponent { }
