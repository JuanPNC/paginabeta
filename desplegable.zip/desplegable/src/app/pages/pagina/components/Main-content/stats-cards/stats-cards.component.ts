import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'stats-cards',
  imports: [],
  templateUrl: './stats-cards.component.html',
  styleUrls: ['./stats-cards.component.css'],
})
export class StatsCardsComponent { }
