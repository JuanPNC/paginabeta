import { ChangeDetectionStrategy, Component } from '@angular/core';
import { SidebarComponent } from '../../components/sidebar/sidebar.component';
import { MainContentComponent } from './components/Main-content/Main-content.component';


@Component({
  selector: 'app-pagina',
  imports: [SidebarComponent, MainContentComponent],
  templateUrl: './pagina.component.html',
  styleUrls: ['./pagina.component.css'],
})
export class PaginaComponent { }
