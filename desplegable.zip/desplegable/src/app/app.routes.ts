import { Routes } from '@angular/router';
import { InformationTabComponent } from './pages/pagina/components/Main-content/dashboard-content/info-cards-section/tab-contents/information-tab/information-tab.component';
import { ButtonsTabComponent } from './pages/pagina/components/Main-content/dashboard-content/info-cards-section/tab-contents/buttons-tab/buttons-tab.component';
import { LinkTabComponent } from './pages/pagina/components/Main-content/dashboard-content/info-cards-section/tab-contents/link-tab/link-tab.component';
import { CalcTabComponent } from './pages/pagina/components/Main-content/dashboard-content/info-cards-section/tab-contents/calc-tab/calc-tab.component';
import { ReportTabComponent } from './pages/pagina/components/Main-content/dashboard-content/info-cards-section/tab-contents/report-tab/report-tab.component';

export const routes: Routes = [

  { path: 'information',
    component: InformationTabComponent 
  },
  { path: 'buttons',
    component: ButtonsTabComponent 
  },
  { path: 'link', 
    component: LinkTabComponent 
  },
  { path: 'calc',
    component: CalcTabComponent 
  },
  { path: 'report', 
    component: ReportTabComponent 
  },
  { path: '**',
    redirectTo: '/information'
  }
];